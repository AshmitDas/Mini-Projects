import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from "@angular/router";
import { GetDataService } from '../services/get-data.service';


@Component({
  selector: 'app-category-page',
  templateUrl: './category-page.component.html',
  styleUrls: ['./category-page.component.css']
})
export class CategoryPageComponent {

  categoryID; 
  allCategoryItems;

  constructor(route: ActivatedRoute, private getData: GetDataService) {
    route.params.subscribe((params) => {
      this.categoryID = params["id"];
      console.log(this.categoryID);

      this.getData.getProductDeatils(`https://fakestoreapi.com/products/category/${this.categoryID}`).subscribe((categoryItems) => {
        console.log(categoryItems);
        this.allCategoryItems = categoryItems;
      })
    });
  }

}
